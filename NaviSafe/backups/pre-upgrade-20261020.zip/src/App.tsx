import { useEffect, useState } from 'react';
import { HashRouter, Navigate, Route, Routes } from 'react-router-dom';
import Navigation from './components/Navigation';
import AnalyticsPage from './pages/AnalyticsPage';
import HomePage from './pages/HomePage';
import LandingPage from './pages/LandingPage';
import AuthPage from './pages/AuthPage';
import MapPage from './pages/MapPage';
import OnboardingPage from './pages/OnboardingPage';
import ReportPage from './pages/ReportPage';
import CheckInPage from './pages/CheckInPage';
import ProfilePage from './pages/ProfilePage';
import './App.css';

export default function App() {
  const [hour, setHour] = useState(20);
  const [alpha, setAlpha] = useState(2);
  const [isOffline, setIsOffline] = useState(!navigator.onLine);

  useEffect(() => {
    const handleOnline = () => setIsOffline(false);
    const handleOffline = () => setIsOffline(true);
    window.addEventListener('online', handleOnline);
    window.addEventListener('offline', handleOffline);
    return () => {
      window.removeEventListener('online', handleOnline);
      window.removeEventListener('offline', handleOffline);
    };
  }, []);

  return (
    <HashRouter>
      <div className="app-shell">
        <Navigation />
        <main className="app-main">
          {isOffline && (
            <div className="offline-banner" role="status">
              <span className="status-dot" />
              Offline mode: cached safety data is available. New updates will queue for sync.
            </div>
          )}
          <Routes>
            <Route path="/" element={<LandingPage />} />
            <Route path="/create-account" element={<AuthPage mode="create" />} />
            <Route path="/signin" element={<AuthPage mode="signin" />} />
            <Route path="/onboarding/:step" element={<OnboardingRoute />} />
            <Route path="/home" element={<HomePage isOffline={isOffline} />} />
            <Route path="/navigate/*" element={<MapPage hour={hour} setHour={setHour} alpha={alpha} setAlpha={setAlpha} />} />
            <Route path="/analytics" element={<AnalyticsPage hour={hour} setHour={setHour} />} />
            <Route path="/community" element={<ReportPage />} />
            <Route path="/report" element={<Navigate to="/community/create" replace />} />
            <Route path="/community/create" element={<ReportPage />} />
            <Route path="/check-in" element={<CheckInPage />} />
            <Route path="/profile" element={<ProfilePage />} />
            <Route path="*" element={<Navigate to="/home" replace />} />
          </Routes>
        </main>
      </div>
    </HashRouter>
  );
}

function OnboardingRoute() {
  const path = window.location.hash.split('/').pop() || 'preferences';
  return <OnboardingPage step={path} />;
}
