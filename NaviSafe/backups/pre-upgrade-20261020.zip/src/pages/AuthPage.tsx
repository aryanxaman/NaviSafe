import { useState } from 'react';
import type { FormEvent } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { ArrowLeft, ArrowRight, Eye, EyeOff, ShieldCheck } from 'lucide-react';

export default function AuthPage({ mode }: { mode: 'create' | 'signin' }) {
  const navigate = useNavigate();
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [form, setForm] = useState({ name: '', email: '', password: '', consent: false });
  const isCreate = mode === 'create';

  const submit = (event: FormEvent) => {
    event.preventDefault();
    if (isCreate && !form.name.trim()) return setError('Please enter your name.');
    if (!form.email.includes('@')) return setError('Enter a valid email address.');
    if (form.password.length < 8) return setError('Use at least 8 characters for your password.');
    if (isCreate && !form.consent) return setError('Please agree to keep your account local for this demo.');
    localStorage.setItem('safepath-account', JSON.stringify({ name: form.name || 'SafePath member', email: form.email }));
    navigate(isCreate ? '/onboarding/preferences' : '/home');
  };

  return <div className="auth-page"><div className="auth-brand"><Link to="/" className="brand"><span className="brand-mark"><ShieldCheck size={20} /></span>SafePath</Link><Link className="back-link" to="/"><ArrowLeft size={15} /> Back to home</Link></div><div className="auth-layout"><div className="auth-aside"><p className="eyebrow">A LITTLE SETUP, A LOT MORE CONTROL</p><h1>{isCreate ? 'Make SafePath yours.' : 'Welcome back.'}</h1><p>{isCreate ? 'Create a lightweight local profile so your preferences, contacts, and drafts have somewhere to live.' : 'Pick up where you left off. Your saved preferences are stored on this device in this demo.'}</p><div className="auth-aside-note"><ShieldCheck size={18} /><span>We will explain every permission before asking for it.</span></div></div><form className="auth-card" onSubmit={submit}><div className="auth-card-heading"><span className="step-count">{isCreate ? '01' : '↗'}</span><div><p className="eyebrow">{isCreate ? 'CREATE ACCOUNT' : 'SIGN IN'}</p><h2>{isCreate ? 'Start with the basics' : 'Continue safely'}</h2></div></div>{isCreate && <label>What should we call you?<input value={form.name} onChange={e => setForm({ ...form, name: e.target.value })} placeholder="Your first name" autoComplete="name" /></label>}<label>Email address<input type="email" value={form.email} onChange={e => setForm({ ...form, email: e.target.value })} placeholder="you@example.com" autoComplete="email" required /></label><label>Password<div className="input-with-action"><input type={showPassword ? 'text' : 'password'} value={form.password} onChange={e => setForm({ ...form, password: e.target.value })} placeholder="At least 8 characters" autoComplete={isCreate ? 'new-password' : 'current-password'} required /><button type="button" aria-label={showPassword ? 'Hide password' : 'Show password'} onClick={() => setShowPassword(!showPassword)}>{showPassword ? <EyeOff size={17} /> : <Eye size={17} />}</button></div></label>{isCreate && <label className="checkbox-label"><input type="checkbox" checked={form.consent} onChange={e => setForm({ ...form, consent: e.target.checked })} /><span>I understand this demo stores account details locally on this device.</span></label>}{error && <p className="form-error" role="alert">{error}</p>}<button className="button button-full" type="submit">{isCreate ? 'Continue setup' : 'Open SafePath'} <ArrowRight size={17} /></button><p className="auth-switch">{isCreate ? 'Already have an account?' : 'New to SafePath?'} <Link to={isCreate ? '/signin' : '/create-account'}>{isCreate ? 'Sign in' : 'Create an account'}</Link></p></form></div></div>;
}
