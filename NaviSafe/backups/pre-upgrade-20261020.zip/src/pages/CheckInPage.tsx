import { useEffect, useState } from 'react';
import type { FormEvent } from 'react';
import { Clock3, HeartPulse, ShieldCheck, UserRound } from 'lucide-react';

type CheckIn = { destination: string; deadline: number; contact: string };
const STORAGE_KEY = 'safepath-active-checkin';

export default function CheckInPage() {
  const [active, setActive] = useState<CheckIn | null>(() => {
    const saved = localStorage.getItem(STORAGE_KEY);
    return saved ? JSON.parse(saved) as CheckIn : null;
  });
  const [destination, setDestination] = useState('');
  const [minutes, setMinutes] = useState('30');
  const [contact, setContact] = useState('');
  const [remaining, setRemaining] = useState(0);

  useEffect(() => {
    if (!active) return;
    const update = () => setRemaining(Math.max(0, active.deadline - Date.now()));
    update();
    const timer = window.setInterval(update, 1000);
    return () => window.clearInterval(timer);
  }, [active]);

  const start = (event: FormEvent) => {
    event.preventDefault();
    const checkIn = { destination, contact: contact || 'No contact selected', deadline: Date.now() + Number(minutes) * 60_000 };
    localStorage.setItem(STORAGE_KEY, JSON.stringify(checkIn));
    setActive(checkIn);
  };
  const clear = () => { localStorage.removeItem(STORAGE_KEY); setActive(null); setRemaining(0); };
  const format = (ms: number) => `${String(Math.floor(ms / 60_000)).padStart(2, '0')}:${String(Math.floor((ms % 60_000) / 1000)).padStart(2, '0')}`;

  return <div className="page checkin-page"><div className="page-header"><div><p className="eyebrow">PRIVATE ARRIVAL REMINDER</p><h1>Check in quietly.</h1><p className="lede">Set a deadline and decide who should know. You can cancel at any time.</p></div><div className="header-status"><span className="status-dot" /> Local timer</div></div>{active ? <div className="active-checkin-panel"><span className="active-checkin-icon"><HeartPulse size={28} /></span><p className="eyebrow">CHECK-IN ACTIVE</p><h2>{format(remaining)}</h2><p className="timer-caption">until your expected arrival at <strong>{active.destination}</strong></p><div className="checkin-details"><span><UserRound size={16} /> {active.contact}</span><span><Clock3 size={16} /> Deadline-based reminder</span></div><div className="checkin-actions"><button className="button" onClick={clear}>I’m safe — finish check-in</button><button className="button button-quiet" onClick={clear}>Cancel timer</button></div><p className="small-note">This browser timer is best-effort. It cannot guarantee background notifications after the app is closed.</p></div> : <div className="checkin-layout"><form className="content-card checkin-form" onSubmit={start}><div className="form-step"><span className="form-step-number">1</span><div><h2>Where are you going?</h2><p className="field-help">A destination helps make the reminder meaningful.</p></div></div><label className="field-label">Destination<input required value={destination} onChange={e => setDestination(e.target.value)} placeholder="e.g. Home, Sector 12" /></label><div className="form-step"><span className="form-step-number">2</span><div><h2>How long should we wait?</h2><p className="field-help">The timer is saved on this device before it starts.</p></div></div><label className="field-label">Expected travel time<select value={minutes} onChange={e => setMinutes(e.target.value)}><option value="15">15 minutes</option><option value="30">30 minutes</option><option value="45">45 minutes</option><option value="60">1 hour</option></select></label><div className="form-step"><span className="form-step-number">3</span><div><h2>Who should be in the loop?</h2><p className="field-help">Choose a trusted contact you have already discussed this with.</p></div></div><label className="field-label">Contact name <span className="optional">optional</span><input value={contact} onChange={e => setContact(e.target.value)} placeholder="e.g. Priya" /></label><button className="button button-full" type="submit">Review and start timer <HeartPulse size={17} /></button></form><aside className="upload-aside"><div className="upload-aside-card"><span className="aside-icon"><ShieldCheck size={20} /></span><h3>What happens next?</h3><ul><li>You confirm before the timer starts.</li><li>You can mark yourself safe or cancel.</li><li>Automatic SMS or calls are not enabled in this demo.</li></ul></div></aside></div>}</div>;
}
