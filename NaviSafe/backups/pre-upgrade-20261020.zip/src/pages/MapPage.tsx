import { useState, useEffect } from 'react';
import { MapContainer, TileLayer, Polyline, useMapEvents, Marker, Rectangle } from 'react-leaflet';
import { Shield, Navigation, Settings, X, Search, Info } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';

const BASE_URL = 'http://localhost:8000/api';
const MAP_CENTER: [number, number] = [28.590, 77.040];

// The bounding box for the Dwarka synthetic dataset
const DWARKA_BOUNDS: [[number, number], [number, number]] = [
  [28.5700, 77.0200],
  [28.6100, 77.0600]
];

function LocationSelector({ setPoints, points, setOriginQuery, setDestQuery }: any) {
  useMapEvents({
    click(e) {
      if (points.length >= 2) {
        setPoints([e.latlng]);
        setOriginQuery(`${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`);
        setDestQuery("");
      } else {
        const newPoints = [...points, e.latlng];
        setPoints(newPoints);
        if (newPoints.length === 1) {
          setOriginQuery(`${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`);
        } else {
          setDestQuery(`${e.latlng.lat.toFixed(4)}, ${e.latlng.lng.toFixed(4)}`);
        }
      }
    },
  });
  return null;
}

export default function MapPage({ hour, setHour, alpha, setAlpha }: any) {
  const [points, setPoints] = useState<any[]>([]);
  const [safestRoute, setSafestRoute] = useState<any>(null);
  const [fastestRoute, setFastestRoute] = useState<any>(null);
  const [showSettings, setShowSettings] = useState(false);
  const [activeRoute, setActiveRoute] = useState<'safest' | 'fastest'>('safest');
  
  const [originQuery, setOriginQuery] = useState("");
  const [destQuery, setDestQuery] = useState("");
  const [isSearching, setIsSearching] = useState(false);

  useEffect(() => {
    if (points.length === 2) {
      fetch(`${BASE_URL}/route`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          start_lat: points[0].lat,
          start_lon: points[0].lng,
          end_lat: points[1].lat,
          end_lon: points[1].lng,
          alpha,
          hour
        })
      })
        .then(res => res.json())
        .then(data => {
          if (data && !data.error) {
            setSafestRoute(data.safest);
            setFastestRoute(data.fastest);
            setActiveRoute('safest');
          }
        }).catch(console.error);
    } else {
      setSafestRoute(null);
      setFastestRoute(null);
    }
  }, [points, alpha, hour]);

  const geocode = async (query: string) => {
    setIsSearching(true);
    try {
      const res = await fetch(
        `https://nominatim.openstreetmap.org/search?format=json&q=${encodeURIComponent(query + ', Dwarka, Delhi, India')}&limit=1`
      );
      const data = await res.json();
      if (data && data.length > 0) {
        setIsSearching(false);
        return { lat: parseFloat(data[0].lat), lng: parseFloat(data[0].lon) };
      }
    } catch (e) {
      console.error(e);
    }
    setIsSearching(false);
    return null;
  };

  const handleKeyDown = async (e: any, type: 'origin' | 'dest', query: string) => {
    if (e.key === 'Enter' && query.trim() !== '') {
      const coords = await geocode(query);
      if (coords) {
        if (type === 'origin') {
          setPoints(prev => prev.length === 0 ? [coords] : [coords, prev[1]].filter(Boolean));
        } else {
          setPoints(prev => prev.length === 0 ? [coords, coords] : [prev[0], coords]);
        }
      }
    }
  };

  const clearSelection = () => {
    setPoints([]);
    setOriginQuery("");
    setDestQuery("");
    setSafestRoute(null);
    setFastestRoute(null);
  };

  return (
    <div style={{ flex: 1, position: 'relative', overflow: 'hidden' }}>

      {/* ── Floating Search Panel ── */}
      <div style={{ position: 'absolute', top: 32, left: 32, zIndex: 1000, width: 420 }}>
        <div className="glass-panel">
          <div style={{ padding: '24px 24px 16px', borderBottom: '1px solid var(--border)', display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
            <h2 style={{ margin: 0, fontSize: 20, fontWeight: 600, letterSpacing: '-0.5px' }}>Route Planner</h2>
            <button
              onClick={() => setShowSettings(!showSettings)}
              style={{
                background: showSettings ? 'rgba(99,102,241,0.15)' : 'rgba(255,255,255,0.05)',
                border: '1px solid var(--border)', borderRadius: '50%', width: 36, height: 36,
                cursor: 'pointer', color: showSettings ? 'var(--primary)' : 'var(--text-muted)',
                display: 'flex', alignItems: 'center', justifyContent: 'center', transition: 'all 0.2s'
              }}
            >
              <Settings size={18} />
            </button>
          </div>

          <div style={{ padding: '24px' }}>
            {/* Origin / Destination connected by line */}
            <div style={{ position: 'relative' }}>
              <div style={{ position: 'absolute', left: 15, top: 24, bottom: 24, width: 2, background: 'var(--border)' }} />

              <div style={{ display: 'flex', alignItems: 'center', gap: 16, marginBottom: 20, position: 'relative', zIndex: 2 }}>
                <div style={{ width: 14, height: 14, borderRadius: '50%', border: '4px solid var(--secondary)', background: 'var(--bg-surface-solid)', boxShadow: '0 0 10px var(--secondary)', flexShrink: 0 }} />
                <div style={{ flex: 1, position: 'relative' }}>
                  <input
                    type="text"
                    placeholder="Search origin or click map"
                    style={{ width: '100%', padding: '14px 16px 14px 40px', borderRadius: 12, fontSize: 14 }}
                    value={originQuery}
                    onChange={e => setOriginQuery(e.target.value)}
                    onKeyDown={e => handleKeyDown(e, 'origin', originQuery)}
                  />
                  <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }} />
                </div>
              </div>

              <div style={{ display: 'flex', alignItems: 'center', gap: 16, position: 'relative', zIndex: 2 }}>
                <div style={{ width: 14, height: 14, borderRadius: '50%', border: '4px solid var(--danger)', background: 'var(--bg-surface-solid)', boxShadow: '0 0 10px rgba(239,68,68,0.5)', flexShrink: 0 }} />
                <div style={{ flex: 1, position: 'relative' }}>
                  <input
                    type="text"
                    placeholder="Search destination or click map"
                    style={{ width: '100%', padding: '14px 16px 14px 40px', borderRadius: 12, fontSize: 14 }}
                    value={destQuery}
                    onChange={e => setDestQuery(e.target.value)}
                    onKeyDown={e => handleKeyDown(e, 'dest', destQuery)}
                  />
                  <Search size={16} color="var(--text-muted)" style={{ position: 'absolute', left: 14, top: '50%', transform: 'translateY(-50%)' }} />
                </div>
              </div>
            </div>

            {isSearching && (
              <div style={{ marginTop: 12, fontSize: 13, color: 'var(--primary)', textAlign: 'center' }}>
                Searching…
              </div>
            )}

            {points.length > 0 && (
              <button
                onClick={clearSelection}
                style={{
                  marginTop: 24, width: '100%', padding: '12px',
                  background: 'rgba(255,255,255,0.05)', border: '1px solid var(--border)', borderRadius: 12,
                  cursor: 'pointer', color: 'var(--text-muted)',
                  display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8,
                  fontSize: 14, fontWeight: 500, fontFamily: 'Outfit, sans-serif'
                }}
              >
                <X size={16} /> Clear Selection
              </button>
            )}
          </div>
        </div>

        <AnimatePresence>
          {showSettings && (
            <motion.div
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="glass-panel"
              style={{ marginTop: 16, padding: 24 }}
            >
              <div style={{ marginBottom: 24 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--text-muted)', marginBottom: 12 }}>
                  <span>Time of Day Simulation</span>
                  <span style={{ fontWeight: 600, color: 'var(--primary)' }}>{hour}:00</span>
                </div>
                <input type="range" min="0" max="23" value={hour} onChange={e => setHour(parseInt(e.target.value))} />
              </div>
              <div>
                <div style={{ display: 'flex', justifyContent: 'space-between', fontSize: 14, color: 'var(--text-muted)', marginBottom: 12 }}>
                  <span>Safety Priority (α)</span>
                  <span style={{ fontWeight: 600, color: 'var(--success)' }}>{alpha}</span>
                </div>
                <input type="range" min="0" max="8" step="0.5" value={alpha} onChange={e => setAlpha(parseFloat(e.target.value))} />
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </div>

      {/* ── Route result cards ── */}
      <AnimatePresence>
        {safestRoute && fastestRoute && (
          <motion.div
            initial={{ opacity: 0, y: 100 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: 100 }}
            style={{ position: 'absolute', bottom: 40, left: '50%', transform: 'translateX(-50%)', zIndex: 1000, display: 'flex', gap: 24 }}
          >
            <RouteCard type="safest" data={safestRoute} active={activeRoute === 'safest'} onClick={() => setActiveRoute('safest')} />
            <RouteCard type="fastest" data={fastestRoute} active={activeRoute === 'fastest'} onClick={() => setActiveRoute('fastest')} />
          </motion.div>
        )}
      </AnimatePresence>

      {/* ── Map ── */}
      <MapContainer center={MAP_CENTER} zoom={14} style={{ height: '100%', width: '100%' }} zoomControl={false}>
        <TileLayer
          url="https://tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a>'
        />
        
        {/* Highlight the selected analysis region (Dwarka) clearly without obstructing streets */}
        <Rectangle 
          bounds={DWARKA_BOUNDS} 
          pathOptions={{ 
            color: 'var(--primary)', 
            weight: 2, 
            dashArray: '10, 10', 
            fillColor: 'var(--primary)', 
            fillOpacity: 0.05 
          }} 
        />
        
        {/* Custom popup/label for the region */}
        <div style={{ position: 'absolute', top: '50%', left: '50%', transform: 'translate(-50%, -50%)', zIndex: 400, pointerEvents: 'none', display: 'flex', flexDirection: 'column', alignItems: 'center', opacity: 0.8 }}>
           <div style={{ padding: '8px 16px', background: 'rgba(7, 11, 20, 0.8)', backdropFilter: 'blur(8px)', borderRadius: 20, border: '1px solid var(--primary)', color: 'var(--text-main)', fontSize: 13, fontWeight: 600, display: 'flex', alignItems: 'center', gap: 8 }}>
             <Info size={14} color="var(--primary)" /> Dwarka Smart City Sector Data
           </div>
        </div>

        <LocationSelector points={points} setPoints={setPoints} setOriginQuery={setOriginQuery} setDestQuery={setDestQuery} />
        {points.map((p, i) => <Marker key={i} position={p} />)}

        {/* Inactive route dashed */}
        {fastestRoute && activeRoute === 'safest' && (
          <Polyline positions={fastestRoute.geometry.map((c: any) => [c[1], c[0]])} color="#6366F1" weight={5} dashArray="8, 12" opacity={0.4} />
        )}
        {safestRoute && activeRoute === 'fastest' && (
          <Polyline positions={safestRoute.geometry.map((c: any) => [c[1], c[0]])} color="#10B981" weight={5} dashArray="8, 12" opacity={0.4} />
        )}
        {/* Active route solid */}
        {activeRoute === 'fastest' && fastestRoute && (
          <Polyline positions={fastestRoute.geometry.map((c: any) => [c[1], c[0]])} color="#6366F1" weight={8} opacity={1} />
        )}
        {activeRoute === 'safest' && safestRoute && (
          <Polyline positions={safestRoute.geometry.map((c: any) => [c[1], c[0]])} color="#10B981" weight={8} opacity={1} />
        )}
      </MapContainer>
    </div>
  );
}

/* ─────────────────── Route Card ─────────────────── */
function RouteCard({ type, data, active, onClick }: { type: 'safest' | 'fastest'; data: any; active: boolean; onClick: () => void }) {
  const isSafe = type === 'safest';
  const color = isSafe ? '#10B981' : '#6366F1';
  const glow = isSafe ? 'rgba(16, 185, 129, 0.4)' : 'rgba(99, 102, 241, 0.5)';
  const Icon = isSafe ? Shield : Navigation;

  return (
    <div
      onClick={onClick}
      className="glass-panel"
      style={{
        padding: 24, width: 320, cursor: 'pointer',
        boxShadow: active ? `0 0 0 2px ${color}, 0 20px 40px -10px ${glow}` : undefined,
        opacity: active ? 1 : 0.6,
        transform: active ? 'scale(1.02)' : 'scale(1)',
        transition: 'all 0.3s cubic-bezier(0.4, 0, 0.2, 1)'
      }}
    >
      <div style={{ display: 'flex', alignItems: 'center', gap: 10, marginBottom: 16, color, fontWeight: 600, fontSize: 15 }}>
        <Icon size={20} strokeWidth={2.5} /> {isSafe ? 'Safest Route' : 'Fastest Route'}
      </div>
      <div style={{ fontSize: 32, fontWeight: 700, marginBottom: 4, letterSpacing: '-1px' }}>
        {Math.round(data.metrics.distance / 10) * 10}{' '}
        <span style={{ fontSize: 16, color: 'var(--text-muted)', fontWeight: 500 }}>m</span>
      </div>
      <div style={{ fontSize: 14, color: 'var(--text-muted)' }}>
        Est. Walk: {Math.round(data.metrics.distance / 1.25 / 60)} min
      </div>
      <div style={{ marginTop: 20, paddingTop: 16, borderTop: '1px solid var(--border)', fontSize: 13, color, fontWeight: 600, display: 'flex', justifyContent: 'space-between' }}>
        <span>Risk Exposure</span>
        <span>{(data.metrics.exposure * 100).toFixed(1)}%</span>
      </div>
    </div>
  );
}
