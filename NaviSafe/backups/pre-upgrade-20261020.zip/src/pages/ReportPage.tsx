import { useState } from 'react';
import type { ChangeEvent, FormEvent } from 'react';
import { AlertTriangle, ArrowLeft, ArrowRight, Camera, Check, FileImage, MapPin, ShieldCheck, UploadCloud, X } from 'lucide-react';

const BASE_URL = 'http://localhost:8000/api';
const categories = [['poor_lighting', 'Poor lighting'], ['isolated', 'Isolated area'], ['incident', 'Incident or concern'], ['safe', 'Feels safe / busy']];

export default function ReportPage() {
  const [data, setData] = useState({ category: '', street: '', desc: '' });
  const [file, setFile] = useState<File | null>(null);
  const [dragging, setDragging] = useState(false);
  const [status, setStatus] = useState<'idle' | 'submitting' | 'queued' | 'sent' | 'error'>('idle');
  const [error, setError] = useState('');
  const chooseFile = (event: ChangeEvent<HTMLInputElement>) => setFile(event.target.files?.[0] || null);
  const submit = async (event: FormEvent) => {
    event.preventDefault();
    if (!data.category) return setError('Choose what you noticed first.');
    setError('');
    setStatus('submitting');
    const form = new FormData();
    form.append('street', data.street); form.append('category', data.category); form.append('desc', data.desc);
    if (file) form.append('file', file);
    try {
      const response = await fetch(`${BASE_URL}/report`, { method: 'POST', body: form });
      if (!response.ok) throw new Error('The report could not be saved.');
      setStatus('sent');
    } catch {
      if (!navigator.onLine) { localStorage.setItem(`safepath-report-${Date.now()}`, JSON.stringify(data)); setStatus('queued'); }
      else { setError('We could not save this update. Check the connection and try again.'); setStatus('error'); }
    }
  };
  if (status === 'sent' || status === 'queued') return <div className="page upload-page"><div className="success-panel"><span className="success-icon"><Check size={30} /></span><p className="eyebrow">{status === 'queued' ? 'QUEUED FOR SYNC' : 'SAVED LOCALLY'}</p><h1>{status === 'queued' ? 'Your update is waiting to sync.' : 'Thanks for helping people plan.'}</h1><p>{status === 'queued' ? 'You are offline, so we have kept the update on this device. It is not published yet.' : 'Your update was sent to the existing SafePath data endpoint. It may still need review before appearing to others.'}</p><a className="button" href="#/home">Back to home <ArrowRight size={17} /></a><button className="text-button" onClick={() => { setStatus('idle'); setData({ category: '', street: '', desc: '' }); setFile(null); }}>Add another update</button></div></div>;
  return <div className="page upload-page"><div className="upload-header"><div><a className="back-link" href="#/home"><ArrowLeft size={15} /> Back to Home</a><p className="eyebrow upload-kicker">COMMUNITY UPDATE</p><h1>Share what you noticed.</h1><p className="lede">A small, specific update can help the next person make a better choice.</p></div><div className="upload-badge"><ShieldCheck size={18} /> Your control</div></div><div className="upload-layout"><form className="upload-card" onSubmit={submit}><div className="form-step"><span className="form-step-number">1</span><div><h2>Where was this?</h2><p className="field-help">Use an area or street name. We do not need your exact home address.</p></div></div><label className="field-label">Area or street<input required value={data.street} onChange={e => setData({ ...data, street: e.target.value })} placeholder="e.g. Sector 12 metro entrance" /><MapPin size={17} /></label><div className="form-step"><span className="form-step-number">2</span><div><h2>What did you notice?</h2><p className="field-help">Pick the closest description. You can add context below.</p></div></div><div className="category-grid">{categories.map(([value, label]) => <button type="button" key={value} className={data.category === value ? 'category selected' : 'category'} onClick={() => setData({ ...data, category: value })}>{data.category === value && <Check size={15} />}{label}</button>)}</div><label className="field-label">A short note <span className="optional">optional · 50 characters max</span><textarea maxLength={50} value={data.desc} onChange={e => setData({ ...data, desc: e.target.value })} placeholder="What would be useful to know?" /><span className="character-count">{data.desc.length}/50</span></label><div className="form-step upload-step-heading"><span className="form-step-number">3</span><div><h2>Add a photo <span className="optional">optional</span></h2><p className="field-help">Only share images you have permission to share. Avoid faces and private details.</p></div></div><div className={`drop-zone ${dragging ? 'dragging' : ''}`} onDragEnter={() => setDragging(true)} onDragLeave={() => setDragging(false)} onDragOver={e => e.preventDefault()} onDrop={e => { e.preventDefault(); setDragging(false); setFile(e.dataTransfer.files[0] || null); }}><input id="report-photo" type="file" accept="image/*" onChange={chooseFile} /><label htmlFor="report-photo">{file ? <><FileImage size={26} /><strong>{file.name}</strong><span>{Math.round(file.size / 1024)} KB · ready to attach</span></> : <><UploadCloud size={27} /><strong>Drop an image here or browse</strong><span>JPG, PNG up to 10 MB</span></>}</label>{file && <button type="button" className="remove-file" aria-label="Remove selected photo" onClick={() => setFile(null)}><X size={15} /></button>}</div>{error && <p className="form-error" role="alert">{error}</p>}<button className="button button-full submit-update" type="submit" disabled={status === 'submitting'}>{status === 'submitting' ? 'Saving update…' : 'Review and share'} <ArrowRight size={17} /></button></form><aside className="upload-aside"><div className="upload-aside-card"><span className="aside-icon"><Camera size={20} /></span><h3>Before you share</h3><ul><li>Keep the location general.</li><li>Do not include someone’s face without consent.</li><li>Your update is reviewed before it becomes community data.</li></ul></div><div className="upload-aside-card privacy-card"><AlertTriangle size={19} /><div><strong>Not for emergencies</strong><p>If you are in immediate danger, contact local emergency services or someone you trust. This form is not monitored in real time.</p></div></div></aside></div></div>;
}
