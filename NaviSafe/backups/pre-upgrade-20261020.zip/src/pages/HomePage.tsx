import { Link } from 'react-router-dom';
import { AlertTriangle, ArrowRight, Check, Compass, HeartPulse, MapPin, ShieldCheck, Users } from 'lucide-react';

type HomePageProps = { isOffline: boolean; focus?: 'check-in' | 'profile' };

export default function HomePage({ isOffline, focus }: HomePageProps) {
  const greeting = focus === 'check-in' ? 'Your check-in space' : focus === 'profile' ? 'Your SafePath profile' : 'Good evening, traveller';
  return (
    <div className="page home-page">
      <header className="page-header">
        <div>
          <p className="eyebrow">YOUR SAFETY COMPANION</p>
          <h1>{greeting}</h1>
          <p className="lede">Plan with more context. Move with more confidence.</p>
        </div>
        <div className="header-status"><span className="status-dot" /> {isOffline ? 'Limited mode' : 'Ready to help'}</div>
      </header>

      <section className="hero-card">
        <div className="hero-copy">
          <span className="icon-badge"><ShieldCheck size={22} /></span>
          <p className="eyebrow">SAFETY STATUS</p>
          <h2>{isOffline ? 'Using your saved safety data' : 'You are in control'}</h2>
          <p>{isOffline ? 'Live updates are paused until your connection returns. Your saved routes and check-in tools remain available.' : 'Choose a route, share a quiet check-in, or tell your community what you noticed.'}</p>
        </div>
        <div className="hero-orbit" aria-hidden="true"><span /><span /><span /></div>
      </section>

      <section className="section-block">
        <div className="section-heading"><div><p className="eyebrow">QUICK ACTIONS</p><h2>What do you need?</h2></div></div>
        <div className="action-grid">
          <Link className="action-card action-navigation" to="/navigate">
            <span className="action-icon"><Compass size={23} /></span><strong>Navigate now</strong>
            <span>Compare routes with safety context <ArrowRight size={16} /></span>
          </Link>
          <Link className="action-card action-checkin" to="/check-in">
            <span className="action-icon"><HeartPulse size={23} /></span><strong>Silent check-in</strong>
            <span>Let trusted people know your ETA <ArrowRight size={16} /></span>
          </Link>
          <Link className="action-card action-emergency" to="/community/create">
            <span className="action-icon"><AlertTriangle size={23} /></span><strong>I feel unsafe</strong>
            <span>Get immediate options and support <ArrowRight size={16} /></span>
          </Link>
        </div>
      </section>

      <section className="dashboard-grid">
        <div className="content-card">
          <div className="card-heading"><div><p className="eyebrow">COMMUNITY PREVIEW</p><h2>What people noticed</h2></div><Link to="/community">See all <ArrowRight size={15} /></Link></div>
          <div className="feed-item"><span className="feed-icon"><MapPin size={17} /></span><div><strong>Sector 12 market</strong><p>Well-lit and busy near the metro entrance.</p><small>Community update · 18 min ago</small></div><span className="tag tag-blue">Well-lit</span></div>
          <div className="feed-item"><span className="feed-icon"><Users size={17} /></span><div><strong>Dwarka Mor crossing</strong><p>More foot traffic than usual this evening.</p><small>Community update · 42 min ago</small></div><span className="tag tag-green">Crowded</span></div>
        </div>
        <div className="content-card checkin-card">
          <div className="card-heading"><div><p className="eyebrow">CHECK-IN</p><h2>Nothing active</h2></div><HeartPulse size={20} /></div>
          <p>Set a private arrival reminder before you leave. SafePath will be clear about what your browser can and cannot do in the background.</p>
          <Link className="text-link" to="/check-in">Set a check-in <ArrowRight size={15} /></Link>
        </div>
      </section>

      <div className="trust-note"><Check size={17} /> Your preferences stay on this device until you choose to share them.</div>
    </div>
  );
}
