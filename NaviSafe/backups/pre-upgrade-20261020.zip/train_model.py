import pandas as pd
import numpy as np
import lightgbm as lgb
from scipy.spatial import cKDTree

print("Loading data...")
edges = pd.read_csv('../synthetic_data/edges_features.csv')
reports = pd.read_csv('../synthetic_data/safecity_synthetic.csv')

# Exclude spam
reports = reports[~reports['_truth_is_spam']]

# Calculate midpoints for snapping
edges['mid_lat'] = edges['lat1'] + (edges['lat2'] - edges['lat1']) / 2
edges['mid_lon'] = edges['lon1'] + (edges['lon2'] - edges['lon1']) / 2

print("Snapping reports to edges...")
tree = cKDTree(edges[['mid_lat', 'mid_lon']].values)
_, idxs = tree.query(reports[['latitude', 'longitude']].values)
reports['snapped_edge_id'] = edges.iloc[idxs]['edge_id'].values

reports['timestamp'] = pd.to_datetime(reports['timestamp'])
reports['hour'] = reports['timestamp'].dt.hour
reports['bucket'] = reports['hour'] // 4

print("Building snapshot dataset...")
data = []
for bucket in range(6):
    bucket_reports = reports[reports['bucket'] == bucket]
    edge_counts = bucket_reports.groupby('snapped_edge_id').size().reset_index(name='count')
    df = edges.copy()
    df['bucket'] = bucket
    df = df.merge(edge_counts, left_on='edge_id', right_on='snapped_edge_id', how='left')
    df['y'] = (df['count'].fillna(0) > 0).astype(int)
    data.append(df)

train_df = pd.concat(data, ignore_index=True)

# Features as per PROJECT.md
features = ['length_m', 'lit', 'dist_metro_m', 'dist_police_m', 'isolated', 'shops_open_night', 'liquor_near', 'police_near', 'footfall_day', 'footfall_night', 'bucket']
X = train_df[features]
y = train_df['y']

print("Training LightGBM model...")
model = lgb.LGBMClassifier(n_estimators=100, random_state=42, verbose=-1)
model.fit(X, y)

train_df['p_ml'] = model.predict_proba(X)[:, 1]

# Save output table
out_df = train_df[['edge_id', 'bucket', 'p_ml']]
out_df.to_csv('../synthetic_data/risk_table.csv', index=False)
print("Model trained and risk_table.csv saved successfully!")
