from fastapi import FastAPI, Request, File, UploadFile, Form
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
import pandas as pd
import networkx as nx
import numpy as np
from datetime import datetime, timezone
import math
import os
import shutil

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

edges_df = pd.read_csv("../synthetic_data/edges_features.csv")

risk_df_path = "../synthetic_data/risk_table.csv"
risk_dict = {}
if os.path.exists(risk_df_path):
    risk_df = pd.read_csv(risk_df_path)
    for idx, row in risk_df.iterrows():
        risk_dict[(row['edge_id'], int(row['bucket']))] = row['p_ml']
else:
    print("Warning: risk_table.csv not found.")

# Create Graph
G = nx.Graph()
nodes_coords = {}
for idx, row in edges_df.iterrows():
    u = row['u']
    v = row['v']
    G.add_edge(u, v, edge_id=row['edge_id'], length=row['length_m'], risk=row['report_propensity'])
    nodes_coords[u] = (row['lat1'], row['lon1'])
    nodes_coords[v] = (row['lat2'], row['lon2'])

def get_nearest_node(lat, lon):
    min_dist = float('inf')
    nearest = None
    for n, (nlat, nlon) in nodes_coords.items():
        dist = (nlat - lat)**2 + (nlon - lon)**2
        if dist < min_dist:
            min_dist = dist
            nearest = n
    return nearest

@app.get("/api/graph")
def get_graph():
    features = []
    for idx, row in edges_df.iterrows():
        features.append({
            "type": "Feature",
            "properties": {
                "edge_id": row['edge_id'],
                "risk": row['report_propensity']
            },
            "geometry": {
                "type": "LineString",
                "coordinates": [
                    [row['lon1'], row['lat1']],
                    [row['lon2'], row['lat2']]
                ]
            }
        })
    return {"type": "FeatureCollection", "features": features}

class RouteReq(BaseModel):
    start_lat: float
    start_lon: float
    end_lat: float
    end_lon: float
    alpha: float
    hour: int

@app.post("/api/route")
def get_route(req: RouteReq):
    start_node = get_nearest_node(req.start_lat, req.start_lon)
    end_node = get_nearest_node(req.end_lat, req.end_lon)
    
    bucket = req.hour // 4
    
    for u, v, d in G.edges(data=True):
        edge_id = d.get('edge_id')
        base_risk = risk_dict.get((edge_id, bucket), d.get('risk', 0))
        d['current_risk'] = base_risk
        d['cost'] = d['length'] * (1.0 + req.alpha * base_risk)
        
    try:
        path = nx.shortest_path(G, source=start_node, target=end_node, weight='cost')
        fastest_path = nx.shortest_path(G, source=start_node, target=end_node, weight='length')
        
        def path_to_geojson(p):
            coords = []
            for n in p:
                lat, lon = nodes_coords[n]
                coords.append([lon, lat])
            return coords
            
        def path_metrics(p):
            dist = 0
            risk_sum = 0
            for i in range(len(p)-1):
                u = p[i]
                v = p[i+1]
                ed = G[u][v]
                dist += ed['length']
                risk_sum += ed['current_risk'] * ed['length']
            return {"distance": dist, "exposure": risk_sum/dist if dist > 0 else 0}
            
        return {
            "safest": {
                "geometry": path_to_geojson(path),
                "metrics": path_metrics(path)
            },
            "fastest": {
                "geometry": path_to_geojson(fastest_path),
                "metrics": path_metrics(fastest_path)
            }
        }
    except Exception as e:
        return {"error": str(e)}

@app.post("/api/report")
async def create_report(
    street: str = Form(...),
    category: str = Form(...),
    desc: str = Form(""),
    file: UploadFile = File(None)
):
    # Save the file
    filepath = None
    if file:
        filepath = os.path.join("uploads", file.filename)
        with open(filepath, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
    
    # Save the report data
    report_data = pd.DataFrame([{
        "timestamp": datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S"),
        "street": street,
        "category": category,
        "description": desc,
        "file_path": filepath
    }])
    
    csv_path = "../synthetic_data/user_reports.csv"
    if not os.path.exists(csv_path):
        report_data.to_csv(csv_path, index=False)
    else:
        report_data.to_csv(csv_path, mode='a', header=False, index=False)
        
    return {"status": "success", "message": "Report saved and added to training queue."}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)
